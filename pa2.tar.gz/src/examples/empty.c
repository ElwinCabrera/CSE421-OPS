#include <stdio.h>
#include <syscall.h>

int main (void){
    
  return EXIT_SUCCESS;
}
